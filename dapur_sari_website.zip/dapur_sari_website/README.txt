DAPUR SARI WEBSITE
==================

CARA MENJALANKAN
1. Ekstrak file ZIP ini.
2. Buka folder dapur_sari_website.
3. Klik dua kali index.html atau buka dengan browser (Chrome, Firefox, Edge).

FITUR
- Website responsif untuk HP dan desktop.
- Halaman Beranda, Tentang Kami, Menu, dan Kontak.
- Keranjang belanja dengan tambah/kurang jumlah dan hapus item.
- Pilihan rasa Pudot: Strawberry, Mangga, Cokelat.
- Checkout meminta nama dan nomor telepon pelanggan.
- Tombol checkout membuka WhatsApp Dapur Sari dengan detail menu, jumlah, total, nama, dan nomor pelanggan yang sudah terisi.

CATATAN
- Nomor WhatsApp tujuan: +62 857-1125-9549.
- Pelanggan tetap perlu menekan tombol Kirim di aplikasi WhatsApp.
- Website ini versi statis; belum terhubung ke database atau sistem pembayaran online.
- Untuk dipublikasikan, unggah seluruh isi folder ini ke layanan hosting website statis.
